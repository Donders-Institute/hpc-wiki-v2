#!/bin/bash
#
# This script demonstrates different way of submitting run_analysis.sh script to run on multiple subjects data in paralle, using Slurm.
#
# Method 1: submit a slurm job for each subject.
#
for id in {0..5}; do
    sbatch --job-name=subj_${id} --time=10:00 --mem=4gb $PWD/run_analysis.sh $id
done

#
# Method 2: submit a sbatch job to allocate overall resources: 6 tasks, one CPU per task, 4 GB memory per CPU.
#           Then run 6 job steps as background processes, each uses a CPU "exclusively".
#
#sbatch --job-name=all_subjects --time=10:00 --ntasks=6 --cpus-per-task=1 --mem-per-cpu=4gb << EOF
#!/bin/bash

#for id in {0..5}; do
#    echo "processing subject \${id}"
#    srun --job-name=subj_\${id} --ntasks=1 --cpus-per-task=1 --exclusive \${PWD}/run_analysis.sh \${id} &
#done

#wait
#EOF
