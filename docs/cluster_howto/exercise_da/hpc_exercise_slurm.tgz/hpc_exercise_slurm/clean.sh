#!/bin/bash

rm -f subject_*/{log,*.jpg,*.png,*.gif,*.svg}
rm -f *.mat
ls *.{o,e}* 2>/dev/null | egrep [0-9]+$ | xargs rm -f
ls slurm-*.out 2>/dev/null | egrep [0-9]+.out$ | xargs rm -f
