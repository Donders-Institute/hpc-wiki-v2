#!/usr/bin/env Rscript

library("tools")

analyze_subject_data <- function(subId) {

    subRootDir <- Sys.getenv("SUBJECT_DIR_ROOT", unset = NA)
    if (is.na(subRootDir)) subRootDir <- getwd()

    subData <- paste(subRootDir, paste("subject_", subId, sep=""), "data", sep="/") 

    url <- system2('/usr/bin/openssl',
                   args=c('enc', '-aes-256-cbc', '-d', '-in', subData, '-pbkdf2', '-k', 'dccn_hpc_tutorial'),
                   stdout=TRUE)

    ext <- file_ext(basename(url))

    out <- paste(subRootDir,
                 paste("subject_", subId, sep=""),
                 paste("photo", file_ext(basename(url)), sep="."), sep="/")

    download.file(url, out, quiet=TRUE, headers=c("User-Agent" = "DccnExercise/1.0 (https://hpc.dccn.nl; helpdesk@donders.ru.nl)"))

    print("done")
}

args = commandArgs(trailingOnly=TRUE)
if (length(args) == 0) {
    stop("missing subject id", call.=FALSE)
} else {
    analyze_subject_data(args[1])
}
