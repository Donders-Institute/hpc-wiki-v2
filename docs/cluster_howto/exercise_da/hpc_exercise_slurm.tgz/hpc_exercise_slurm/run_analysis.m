function out = run_analysis(id)

    subRootDir = getenv('SUBJECT_DIR_ROOT');

    if ( isempty(subRootDir) ) 
        subRootDir = pwd;
    end

    subData = fullfile(subRootDir, strcat('subject_', num2str(id)), "data");

    [~, url] = system('/usr/bin/openssl enc -aes-256-cbc -d -in ' + subData + ' -pbkdf2 -k dccn_hpc_tutorial');
    [~, ~, ext] = fileparts(strtrim(url));

    woptions = weboptions('UserAgent', 'DccnExercise/1.0 (https://hpc.dccn.nl; helpdesk@donders.ru.nl)');

    out = websave(fullfile(subRootDir, strcat('subject_', num2str(id)), "photo" + ext), url, woptions);

end
