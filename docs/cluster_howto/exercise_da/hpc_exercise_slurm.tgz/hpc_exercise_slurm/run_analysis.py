#!/usr/bin/env python
import os
import os.path
import sys

# extra packages
import requests

def analyze_subject_data(subId):

    # root path in which data of subjects are available
    subDirRoot = os.getenv('SUBJECT_DIR_ROOT')
    if not subDirRoot:
        subDirRoot = os.getcwd()

    subData = os.path.join(subDirRoot, 'subject_' + subId, "data")

    decryptPass = 'dccn_hpc_tutorial'

    p = os.popen('/usr/bin/openssl enc -aes-256-cbc -d -in ' + subData + ' -pbkdf2 -k ' + decryptPass)
    url = p.readline().strip()
    p.close()

    fparts = os.path.basename(url).split('.')
    fout = os.path.join(subDirRoot, 'subject_' + subId, "photo." + fparts[-1] if len(fparts) > 1 else "photo")

    headers = {'User-Agent': 'DccnExercise/1.0 (https://hpc.dccn.nl; helpdesk@donders.ru.nl)'}

    r = requests.get(url, allow_redirects=True, headers=headers)
    f = open(fout, 'wb')
    f.write(r.content)
    f.close()

    print("done")

## main program
if __name__=='__main__':

    if len(sys.argv) < 2:
        sys.exit("usage: " + sys.argv[0] + " [subjectId]")

    analyze_subject_data(sys.argv[1])

