% a simple function to check status of jobs created by qsubfeval
%
% it requires the qsub_toolbox: https://www.fieldtriptoolbox.org/faq/how_to_get_started_with_distributed_computing_using_qsub/
%
% on the DCCN HPC cluster, the qusb_toolbox can be loaded via
%
% >> addpath '/home/common/matlab/fieldtrip/qsub/'
%
function check_jobs(jobs)
    for j = jobs
        jid = qsublist('getpbsid', j);
        system(sprintf("scontrol show job %s", jid));
    end
end
